$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("file:src/test/resources/features/fieldsValidations.feature");
formatter.feature({
  "name": "Verify Drop down-AplaNumericField-Numeric fields",
  "description": "",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@fieldsValidations"
    }
  ]
});
formatter.scenarioOutline({
  "name": "Verify Drop down Selection",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@dropDown"
    }
  ]
});
formatter.step({
  "name": "user launch application",
  "keyword": "Given "
});
formatter.step({
  "name": "user accept application permissions \"USD\" \"Let me handle it\" \"Disable crash reports\"",
  "keyword": "When "
});
formatter.step({
  "name": "user should see the dash board screen",
  "keyword": "Then "
});
formatter.step({
  "name": "user tap on plus icon to create new account",
  "keyword": "And "
});
formatter.step({
  "name": "user fills new account name field with \"\u003caccountName\u003e\"",
  "keyword": "And "
});
formatter.step({
  "name": "user selects the \"\u003ccurrency\u003e\" from the drop down",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "accountName",
        "currency"
      ]
    },
    {
      "cells": [
        "dropdownselect",
        "USD - US Dollar"
      ]
    }
  ]
});
formatter.scenario({
  "name": "Verify Drop down Selection",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@fieldsValidations"
    },
    {
      "name": "@dropDown"
    }
  ]
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "user launch application",
  "keyword": "Given "
});
formatter.match({
  "location": "GnuCashSetupStepDefinitions.user_launch_application()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user accept application permissions \"USD\" \"Let me handle it\" \"Disable crash reports\"",
  "keyword": "When "
});
formatter.match({
  "location": "GnuCashSetupStepDefinitions.user_accept_application_permissions(String,String,String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user should see the dash board screen",
  "keyword": "Then "
});
formatter.match({
  "location": "AccountStepDefinitions.user_should_see_the_dash_board_screen()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user tap on plus icon to create new account",
  "keyword": "And "
});
formatter.match({
  "location": "AccountStepDefinitions.user_tap_on_plus_icon_to_create_new_account()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user fills new account name field with \"dropdownselect\"",
  "keyword": "And "
});
formatter.match({
  "location": "AccountStepDefinitions.user_fills_new_account_name_field_with(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user selects the \"USD - US Dollar\" from the drop down",
  "keyword": "Then "
});
formatter.match({
  "location": "AccountStepDefinitions.user_selects_the_from_the_drop_down(String)"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded0.png", "Verify Drop down Selection");
formatter.after({
  "status": "passed"
});
formatter.scenarioOutline({
  "name": "Verify alphaNumeric input field",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@aplhaNumeric"
    }
  ]
});
formatter.step({
  "name": "user launch application",
  "keyword": "Given "
});
formatter.step({
  "name": "user accept application permissions \"USD\" \"Let me handle it\" \"Disable crash reports\"",
  "keyword": "When "
});
formatter.step({
  "name": "user should see the dash board screen",
  "keyword": "Then "
});
formatter.step({
  "name": "user tap on plus icon to create new account",
  "keyword": "And "
});
formatter.step({
  "name": "user fills new account name field with \"\u003caccountName\u003e\"",
  "keyword": "And "
});
formatter.step({
  "name": "user tap on save button",
  "keyword": "And "
});
formatter.step({
  "name": "user should see the \"\u003caccountName\u003e\" in dash board list",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "accountName"
      ]
    },
    {
      "cells": [
        "alphanumeric123"
      ]
    }
  ]
});
formatter.scenario({
  "name": "Verify alphaNumeric input field",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@fieldsValidations"
    },
    {
      "name": "@aplhaNumeric"
    }
  ]
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "user launch application",
  "keyword": "Given "
});
formatter.match({
  "location": "GnuCashSetupStepDefinitions.user_launch_application()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user accept application permissions \"USD\" \"Let me handle it\" \"Disable crash reports\"",
  "keyword": "When "
});
formatter.match({
  "location": "GnuCashSetupStepDefinitions.user_accept_application_permissions(String,String,String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user should see the dash board screen",
  "keyword": "Then "
});
formatter.match({
  "location": "AccountStepDefinitions.user_should_see_the_dash_board_screen()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user tap on plus icon to create new account",
  "keyword": "And "
});
formatter.match({
  "location": "AccountStepDefinitions.user_tap_on_plus_icon_to_create_new_account()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user fills new account name field with \"alphanumeric123\"",
  "keyword": "And "
});
formatter.match({
  "location": "AccountStepDefinitions.user_fills_new_account_name_field_with(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user tap on save button",
  "keyword": "And "
});
formatter.match({
  "location": "AccountStepDefinitions.user_tap_on_save_button()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user should see the \"alphanumeric123\" in dash board list",
  "keyword": "Then "
});
formatter.match({
  "location": "GnuCashSetupStepDefinitions.user_should_see_the_in_dash_board_list(String)"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded1.png", "Verify alphaNumeric input field");
formatter.after({
  "status": "passed"
});
formatter.scenarioOutline({
  "name": "Verify numeric field Selection",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@numeric"
    }
  ]
});
formatter.step({
  "name": "user launch application",
  "keyword": "Given "
});
formatter.step({
  "name": "user accept application permissions \"USD\" \"Let me handle it\" \"Disable crash reports\"",
  "keyword": "When "
});
formatter.step({
  "name": "user should see the dash board screen",
  "keyword": "Then "
});
formatter.step({
  "name": "user tap on plus icon to create new account",
  "keyword": "And "
});
formatter.step({
  "name": "user fills new account name field with \"\u003caccountName\u003e\"",
  "keyword": "And "
});
formatter.step({
  "name": "user tap on save button",
  "keyword": "And "
});
formatter.step({
  "name": "user should see the \"\u003caccountName\u003e\" in dash board list",
  "keyword": "Then "
});
formatter.step({
  "name": "user should select account from the list \"\u003caccountName\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "name": "user tap on plus icon to create new transaction",
  "keyword": "And "
});
formatter.step({
  "name": "user fills the \"\u003camount\u003e\" field",
  "keyword": "Then "
});
formatter.step({
  "name": "user click on save button in new transaction page",
  "keyword": "Then "
});
formatter.step({
  "name": "user should verify amount field allows only numberic values",
  "keyword": "And "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "accountName",
        "amount"
      ]
    },
    {
      "cells": [
        "alphanumeric123",
        "500*"
      ]
    }
  ]
});
formatter.scenario({
  "name": "Verify numeric field Selection",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@fieldsValidations"
    },
    {
      "name": "@numeric"
    }
  ]
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "user launch application",
  "keyword": "Given "
});
formatter.match({
  "location": "GnuCashSetupStepDefinitions.user_launch_application()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user accept application permissions \"USD\" \"Let me handle it\" \"Disable crash reports\"",
  "keyword": "When "
});
formatter.match({
  "location": "GnuCashSetupStepDefinitions.user_accept_application_permissions(String,String,String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user should see the dash board screen",
  "keyword": "Then "
});
formatter.match({
  "location": "AccountStepDefinitions.user_should_see_the_dash_board_screen()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user tap on plus icon to create new account",
  "keyword": "And "
});
formatter.match({
  "location": "AccountStepDefinitions.user_tap_on_plus_icon_to_create_new_account()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user fills new account name field with \"alphanumeric123\"",
  "keyword": "And "
});
formatter.match({
  "location": "AccountStepDefinitions.user_fills_new_account_name_field_with(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user tap on save button",
  "keyword": "And "
});
formatter.match({
  "location": "AccountStepDefinitions.user_tap_on_save_button()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user should see the \"alphanumeric123\" in dash board list",
  "keyword": "Then "
});
formatter.match({
  "location": "GnuCashSetupStepDefinitions.user_should_see_the_in_dash_board_list(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user should select account from the list \"alphanumeric123\"",
  "keyword": "Then "
});
formatter.match({
  "location": "AccountStepDefinitions.user_should_select_account_from_the_list(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user tap on plus icon to create new transaction",
  "keyword": "And "
});
formatter.match({
  "location": "AccountStepDefinitions.user_tap_on_plus_icon_to_create_new_transaction()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user fills the \"500*\" field",
  "keyword": "Then "
});
formatter.match({
  "location": "AccountStepDefinitions.user_fills_the_field(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user click on save button in new transaction page",
  "keyword": "Then "
});
formatter.match({
  "location": "AccountStepDefinitions.user_click_on_save_button()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user should verify amount field allows only numberic values",
  "keyword": "And "
});
formatter.match({
  "location": "AccountStepDefinitions.user_should_verify_amount_field_allows_only_numberic_values()"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded2.png", "Verify numeric field Selection");
formatter.after({
  "status": "passed"
});
formatter.scenario({
  "name": "Verify pageNavigation assertions",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@fieldsValidations"
    },
    {
      "name": "@pageNavigations"
    }
  ]
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "user launch application",
  "keyword": "Given "
});
formatter.match({
  "location": "GnuCashSetupStepDefinitions.user_launch_application()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user validates \"Welcome to GnuCash\" screen title",
  "keyword": "When "
});
formatter.match({
  "location": "GnuCashSetupStepDefinitions.user_validates_screen_title(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user tap on next button",
  "keyword": "When "
});
formatter.match({
  "location": "GnuCashSetupStepDefinitions.user_tap_on_next_button()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user validates \"Default Currency\" screen title",
  "keyword": "And "
});
formatter.match({
  "location": "GnuCashSetupStepDefinitions.user_validates_screen_title(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user tap on next button",
  "keyword": "When "
});
formatter.match({
  "location": "GnuCashSetupStepDefinitions.user_tap_on_next_button()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user validates \"Account Setup\" screen title",
  "keyword": "And "
});
formatter.match({
  "location": "GnuCashSetupStepDefinitions.user_validates_screen_title(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user tap on next button",
  "keyword": "When "
});
formatter.match({
  "location": "GnuCashSetupStepDefinitions.user_tap_on_next_button()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user validates \"Feedback Options\" screen title",
  "keyword": "And "
});
formatter.match({
  "location": "GnuCashSetupStepDefinitions.user_validates_screen_title(String)"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded3.png", "Verify pageNavigation assertions");
formatter.after({
  "status": "passed"
});
formatter.scenarioOutline({
  "name": "Verify search field",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@search"
    }
  ]
});
formatter.step({
  "name": "user launch application",
  "keyword": "Given "
});
formatter.step({
  "name": "user accept application permissions \"USD\" \"Let me handle its\" \"Disable crash reports\"",
  "keyword": "When "
});
formatter.step({
  "name": "user should see the dash board screen",
  "keyword": "Then "
});
formatter.step({
  "name": "user tap on plus icon to create new account",
  "keyword": "And "
});
formatter.step({
  "name": "user fills new account name field with \"\u003caccountName\u003e\"",
  "keyword": "And "
});
formatter.step({
  "name": "user tap on save button",
  "keyword": "And "
});
formatter.step({
  "name": "user search for created account \"\u003caccountName\u003e\"",
  "keyword": "And "
});
formatter.step({
  "name": "user should see the \"\u003caccountName\u003e\" in dash board list",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "accountName"
      ]
    },
    {
      "cells": [
        "alphanumeric123"
      ]
    }
  ]
});
formatter.scenario({
  "name": "Verify search field",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@fieldsValidations"
    },
    {
      "name": "@search"
    }
  ]
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "user launch application",
  "keyword": "Given "
});
formatter.match({
  "location": "GnuCashSetupStepDefinitions.user_launch_application()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user accept application permissions \"USD\" \"Let me handle its\" \"Disable crash reports\"",
  "keyword": "When "
});
formatter.match({
  "location": "GnuCashSetupStepDefinitions.user_accept_application_permissions(String,String,String)"
});
formatter.result({
  "error_message": "org.openqa.selenium.NoSuchElementException: An element could not be located on the page using the given search parameters.\nFor documentation on this error, please visit: https://www.seleniumhq.org/exceptions/no_such_element.html\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:17:03\u0027\nSystem info: host: \u0027Reddi-Kothapalli.local\u0027, ip: \u0027fe80:0:0:0:1c8f:b591:185a:306f%en0\u0027, os.name: \u0027Mac OS X\u0027, os.arch: \u0027x86_64\u0027, os.version: \u002710.15.4\u0027, java.version: \u00271.8.0_231\u0027\nDriver info: io.appium.java_client.android.AndroidDriver\nCapabilities {app: /Users/treddi/git/moneylion..., appActivity: org.gnucash.android.ui.acco..., appPackage: org.gnucash.android, databaseEnabled: false, desired: {app: /Users/treddi/git/moneylion..., appActivity: org.gnucash.android.ui.acco..., appPackage: org.gnucash.android, deviceName: emulator-5554, platformName: android, platformVersion: 7.1.1}, deviceApiLevel: 25, deviceManufacturer: Google, deviceModel: Android SDK built for x86, deviceName: emulator-5554, deviceScreenDensity: 240, deviceScreenSize: 480x800, deviceUDID: emulator-5554, javascriptEnabled: true, locationContextEnabled: false, networkConnectionEnabled: true, pixelRatio: 1.5, platform: LINUX, platformName: Android, platformVersion: 7.1.1, statBarHeight: 36, takesScreenshot: true, viewportRect: {height: 764, left: 0, top: 36, width: 480}, warnings: {}, webStorageEnabled: false}\nSession ID: 15179dd3-07a4-4916-bf0e-398ad5385153\n*** Element info: {Using\u003dxpath, value\u003d//*[@text\u003d\u0027Let me handle its\u0027]}\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:187)\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:122)\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\n\tat io.appium.java_client.remote.AppiumCommandExecutor.execute(AppiumCommandExecutor.java:239)\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:552)\n\tat io.appium.java_client.DefaultGenericMobileDriver.execute(DefaultGenericMobileDriver.java:41)\n\tat io.appium.java_client.AppiumDriver.execute(AppiumDriver.java:1)\n\tat io.appium.java_client.android.AndroidDriver.execute(AndroidDriver.java:1)\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:323)\n\tat io.appium.java_client.DefaultGenericMobileDriver.findElement(DefaultGenericMobileDriver.java:61)\n\tat io.appium.java_client.AppiumDriver.findElement(AppiumDriver.java:1)\n\tat io.appium.java_client.android.AndroidDriver.findElement(AndroidDriver.java:1)\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementByXPath(RemoteWebDriver.java:428)\n\tat io.appium.java_client.DefaultGenericMobileDriver.findElementByXPath(DefaultGenericMobileDriver.java:151)\n\tat io.appium.java_client.AppiumDriver.findElementByXPath(AppiumDriver.java:1)\n\tat io.appium.java_client.android.AndroidDriver.findElementByXPath(AndroidDriver.java:1)\n\tat org.openqa.selenium.By$ByXPath.findElement(By.java:353)\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:315)\n\tat io.appium.java_client.DefaultGenericMobileDriver.findElement(DefaultGenericMobileDriver.java:57)\n\tat io.appium.java_client.AppiumDriver.findElement(AppiumDriver.java:1)\n\tat io.appium.java_client.android.AndroidDriver.findElement(AndroidDriver.java:1)\n\tat com.ml.moneylion.screen.GNUSetupScreen.getRadioOptions(GNUSetupScreen.java:36)\n\tat com.ml.moneylion.screen.GNUSetupScreen.selectGNUPreSetupRadioBtns(GNUSetupScreen.java:62)\n\tat com.ml.moneylion.screen.GNUSetupScreen.gnuCashPreSetup(GNUSetupScreen.java:105)\n\tat com.ml.moneylion.stepdefinitions.GnuCashSetupStepDefinitions.user_accept_application_permissions(GnuCashSetupStepDefinitions.java:24)\n\tat ✽.user accept application permissions \"USD\" \"Let me handle its\" \"Disable crash reports\"(file:src/test/resources/features/fieldsValidations.feature:64)\n",
  "status": "failed"
});
formatter.step({
  "name": "user should see the dash board screen",
  "keyword": "Then "
});
formatter.match({
  "location": "AccountStepDefinitions.user_should_see_the_dash_board_screen()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "user tap on plus icon to create new account",
  "keyword": "And "
});
formatter.match({
  "location": "AccountStepDefinitions.user_tap_on_plus_icon_to_create_new_account()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "user fills new account name field with \"alphanumeric123\"",
  "keyword": "And "
});
formatter.match({
  "location": "AccountStepDefinitions.user_fills_new_account_name_field_with(String)"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "user tap on save button",
  "keyword": "And "
});
formatter.match({
  "location": "AccountStepDefinitions.user_tap_on_save_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "user search for created account \"alphanumeric123\"",
  "keyword": "And "
});
formatter.match({
  "location": "AccountStepDefinitions.user_search_for_created_account(String)"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "user should see the \"alphanumeric123\" in dash board list",
  "keyword": "Then "
});
formatter.match({
  "location": "GnuCashSetupStepDefinitions.user_should_see_the_in_dash_board_list(String)"
});
formatter.result({
  "status": "skipped"
});
formatter.embedding("image/png", "embedded4.png", "Verify search field");
formatter.after({
  "status": "passed"
});
});